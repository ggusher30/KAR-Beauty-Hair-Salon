package parlorservicesandpayment;

import javax.swing.JOptionPane;

public class B_AdminPage extends javax.swing.JFrame {

    String HairCut = "None", HairColor = "None", HairStyle = "None", Waxing = "None", NailTreatment = "None";
    double haircutP, haircolorP, hairstyleP, waxingP, nailtreatmentP, total, vat;
    
    int size = 10, value = 1;
    String customers[]= new String[size], 
           customersCn[] = new String [size],
           haircutChoice[] = new String[size],
           haircolorChoice[] = new String [size],
           hairstyleChoice[] = new String [size],
           waxingChoice[] = new String [size],
           nailtreatmentChoice[] = new String [size];
    String customerName, contactNumber, s1, s2, s3, s4, s5;
    int queNumber[] = new int[size];
    int customerQueNum;

    int front= -1, rear= -1;    
    
    public B_AdminPage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        warning = new javax.swing.JOptionPane();
        mop = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        pricelist = new javax.swing.JFrame();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Services = new javax.swing.JPanel();
        d1 = new javax.swing.JCheckBox();
        jLabel112 = new javax.swing.JLabel();
        d3 = new javax.swing.JCheckBox();
        d6 = new javax.swing.JCheckBox();
        d5 = new javax.swing.JCheckBox();
        d2 = new javax.swing.JCheckBox();
        d4 = new javax.swing.JCheckBox();
        jLabel107 = new javax.swing.JLabel();
        e1 = new javax.swing.JCheckBox();
        e4 = new javax.swing.JCheckBox();
        e5 = new javax.swing.JCheckBox();
        e2 = new javax.swing.JCheckBox();
        e3 = new javax.swing.JCheckBox();
        e6 = new javax.swing.JCheckBox();
        c1 = new javax.swing.JCheckBox();
        c4 = new javax.swing.JCheckBox();
        c5 = new javax.swing.JCheckBox();
        c2 = new javax.swing.JCheckBox();
        c3 = new javax.swing.JCheckBox();
        c6 = new javax.swing.JCheckBox();
        jLabel111 = new javax.swing.JLabel();
        b4 = new javax.swing.JCheckBox();
        jLabel110 = new javax.swing.JLabel();
        b1 = new javax.swing.JCheckBox();
        b2 = new javax.swing.JCheckBox();
        b5 = new javax.swing.JCheckBox();
        b6 = new javax.swing.JCheckBox();
        b3 = new javax.swing.JCheckBox();
        a3 = new javax.swing.JCheckBox();
        a6 = new javax.swing.JCheckBox();
        a5 = new javax.swing.JCheckBox();
        a2 = new javax.swing.JCheckBox();
        a4 = new javax.swing.JCheckBox();
        a1 = new javax.swing.JCheckBox();
        jLabel109 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cbCash = new javax.swing.JCheckBox();
        cbEwallet = new javax.swing.JCheckBox();
        lEwallet = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        txAmount = new javax.swing.JTextField();
        btnPayNow = new javax.swing.JButton();
        txCn = new javax.swing.JTextField();
        txName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnPriceList = new javax.swing.JToggleButton();
        jLabel32 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        btnSubmit = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lmop = new javax.swing.JLabel();
        dName = new javax.swing.JLabel();
        dCn = new javax.swing.JLabel();
        Change = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        l1 = new javax.swing.JLabel();
        l3 = new javax.swing.JLabel();
        Cash = new javax.swing.JLabel();
        TotalAmount = new javax.swing.JLabel();
        jToggleButton2 = new javax.swing.JToggleButton();
        jPanel5 = new javax.swing.JPanel();
        lSched2 = new javax.swing.JLabel();
        haircut = new javax.swing.JLabel();
        haircolor = new javax.swing.JLabel();
        lSched3 = new javax.swing.JLabel();
        lSched4 = new javax.swing.JLabel();
        hairstyle = new javax.swing.JLabel();
        waxing = new javax.swing.JLabel();
        lSched5 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        nailtreatment = new javax.swing.JLabel();
        label3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        haircutPrice = new javax.swing.JLabel();
        haircolorPrice = new javax.swing.JLabel();
        hairstylePrice = new javax.swing.JLabel();
        waxingPrice = new javax.swing.JLabel();
        nailtreatmentPrice = new javax.swing.JLabel();
        vatP = new javax.swing.JLabel();
        totalprice = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnEnqueue = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        queueList = new java.awt.List();
        jLabel106 = new javax.swing.JLabel();
        btnDequeue = new javax.swing.JButton();
        btnLogOut = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();

        pricelist.setBounds(new java.awt.Rectangle(1000, 100, 626, 847));

        jPanel7.setBackground(new java.awt.Color(232, 227, 215));
        jPanel7.setPreferredSize(new java.awt.Dimension(626, 847));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Monospaced", 0, 18)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("Pixie Cut..........₱250\nUndercut...........₱350\nHair Trimming......₱150\nStraight Bob.......₱200\nLayered Hair.......₱300\nAngled Bob.........₱200\n\n\n\n");
        jTextArea1.setBorder(null);
        jScrollPane2.setViewportView(jTextArea1);

        jPanel7.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 330, 300));

        jLabel9.setText("Hair Cut");
        jPanel7.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, -1, -1));

        javax.swing.GroupLayout pricelistLayout = new javax.swing.GroupLayout(pricelist.getContentPane());
        pricelist.getContentPane().setLayout(pricelistLayout);
        pricelistLayout.setHorizontalGroup(
            pricelistLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pricelistLayout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pricelistLayout.setVerticalGroup(
            pricelistLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pricelistLayout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("K.A.R Beauty and Hair Parlor");
        setBounds(new java.awt.Rectangle(0, 0, 1900, 1130));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(232, 227, 215));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setEnabled(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(1300, 850));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(210, 176, 176));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel7.setText("Price");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 0, -1, 40));

        jLabel10.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel10.setText("Availed Services");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, -1, 40));

        jLabel11.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel11.setText("Customer's Details");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 0, -1, 40));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 700, 1020, 40));

        Services.setBackground(new java.awt.Color(232, 227, 215));
        Services.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        d1.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup4.add(d1);
        d1.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        d1.setText("Waxing Underarm");
        d1.setOpaque(false);
        Services.add(d1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 190, 40));

        jLabel112.setFont(new java.awt.Font("Poor Richard", 1, 24)); // NOI18N
        jLabel112.setText("Waxing");
        Services.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 90, 30));

        d3.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup4.add(d3);
        d3.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        d3.setText("Waxing Both Leg");
        d3.setOpaque(false);
        Services.add(d3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, 180, 40));

        d6.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup4.add(d6);
        d6.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        d6.setText("Waxing Full Back");
        d6.setOpaque(false);
        Services.add(d6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 180, 40));

        d5.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup4.add(d5);
        d5.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        d5.setText("Waxing Eyebrow");
        d5.setOpaque(false);
        Services.add(d5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 420, -1, 40));

        d2.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup4.add(d2);
        d2.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        d2.setText("Waxing Stomach");
        d2.setOpaque(false);
        Services.add(d2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 190, 40));

        d4.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup4.add(d4);
        d4.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        d4.setText("Waxing Full Face");
        d4.setOpaque(false);
        Services.add(d4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 180, 40));

        jLabel107.setFont(new java.awt.Font("Poor Richard", 1, 24)); // NOI18N
        jLabel107.setText("Nail Treatments");
        Services.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 200, 30));

        e1.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup5.add(e1);
        e1.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        e1.setText("Basic Manicure");
        e1.setOpaque(false);
        Services.add(e1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 190, 40));

        e4.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup5.add(e4);
        e4.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        e4.setText("Gel Manicure");
        e4.setOpaque(false);
        Services.add(e4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, 180, 40));

        e5.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup5.add(e5);
        e5.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        e5.setText("Acrylic Nails");
        e5.setOpaque(false);
        Services.add(e5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 530, -1, 40));

        e2.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup5.add(e2);
        e2.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        e2.setText("French Manicure");
        e2.setOpaque(false);
        Services.add(e2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 500, 190, 40));

        e3.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup5.add(e3);
        e3.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        e3.setText("Paraffin Wax Manicure");
        e3.setOpaque(false);
        Services.add(e3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 500, 240, 40));

        e6.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup5.add(e6);
        e6.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        e6.setText("Hot Oil Manicure");
        e6.setOpaque(false);
        Services.add(e6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 530, 180, 40));

        c1.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup3.add(c1);
        c1.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        c1.setText("Straight Hair");
        c1.setOpaque(false);
        Services.add(c1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 150, 40));

        c4.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup3.add(c4);
        c4.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        c4.setText("Voluminous Curls");
        c4.setOpaque(false);
        Services.add(c4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 180, 40));

        c5.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup3.add(c5);
        c5.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        c5.setText("Tousled Waves Hair");
        c5.setOpaque(false);
        Services.add(c5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 310, -1, 40));

        c2.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup3.add(c2);
        c2.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        c2.setText("Loose Waves");
        c2.setOpaque(false);
        Services.add(c2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 190, 40));

        c3.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup3.add(c3);
        c3.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        c3.setText("End Curls");
        c3.setOpaque(false);
        Services.add(c3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 280, 160, 40));

        c6.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup3.add(c6);
        c6.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        c6.setText("Coily Curls");
        c6.setOpaque(false);
        Services.add(c6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 310, 140, 40));

        jLabel111.setFont(new java.awt.Font("Poor Richard", 1, 24)); // NOI18N
        jLabel111.setText("Hair Style");
        Services.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 110, 30));

        b4.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup2.add(b4);
        b4.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        b4.setText("Ombre");
        b4.setOpaque(false);
        Services.add(b4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 150, 40));

        jLabel110.setFont(new java.awt.Font("Poor Richard", 1, 24)); // NOI18N
        jLabel110.setText("Hair Color");
        Services.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 120, 30));

        b1.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup2.add(b1);
        b1.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        b1.setText("Highlights");
        b1.setOpaque(false);
        Services.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 120, 40));

        b2.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup2.add(b2);
        b2.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        b2.setText("Ashgray Hair Color");
        b2.setOpaque(false);
        Services.add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 190, 40));

        b5.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup2.add(b5);
        b5.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        b5.setText("Caramel Highlights");
        b5.setOpaque(false);
        Services.add(b5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, 180, 40));

        b6.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup2.add(b6);
        b6.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        b6.setText("Auburn Hair Color");
        b6.setOpaque(false);
        Services.add(b6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 190, 180, 40));

        b3.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup2.add(b3);
        b3.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        b3.setText("Under Hair Color");
        b3.setOpaque(false);
        Services.add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 160, 160, 40));

        a3.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup1.add(a3);
        a3.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        a3.setText("Hair Trimming");
        a3.setOpaque(false);
        Services.add(a3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 160, 40));

        a6.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup1.add(a6);
        a6.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        a6.setText("Angled Bob");
        a6.setOpaque(false);
        Services.add(a6, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, 140, 40));

        a5.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup1.add(a5);
        a5.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        a5.setText("Layered Hair");
        a5.setOpaque(false);
        Services.add(a5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, 140, 40));

        a2.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup1.add(a2);
        a2.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        a2.setText("Undercut");
        a2.setOpaque(false);
        Services.add(a2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 50, 120, 40));

        a4.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup1.add(a4);
        a4.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        a4.setText("Straight Bob");
        a4.setOpaque(false);
        Services.add(a4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 150, 40));

        a1.setBackground(new java.awt.Color(210, 176, 176));
        buttonGroup1.add(a1);
        a1.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        a1.setText("Pixie Cut");
        a1.setOpaque(false);
        Services.add(a1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 120, 40));

        jLabel109.setFont(new java.awt.Font("Poor Richard", 1, 24)); // NOI18N
        jLabel109.setText("Hair Cut");
        Services.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 90, 30));

        jPanel2.setBackground(new java.awt.Color(132, 150, 134));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel3.setText("Customer's Payment Method:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        mop.add(cbCash);
        cbCash.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        cbCash.setText("Cash");
        cbCash.setEnabled(false);
        cbCash.setOpaque(false);
        cbCash.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                cbCashStateChanged(evt);
            }
        });
        jPanel2.add(cbCash, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 289, -1, 20));

        mop.add(cbEwallet);
        cbEwallet.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        cbEwallet.setText("E-Wallet");
        cbEwallet.setEnabled(false);
        cbEwallet.setOpaque(false);
        jPanel2.add(cbEwallet, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, -1, 30));

        lEwallet.setFont(new java.awt.Font("Tw Cen MT", 1, 17)); // NOI18N
        lEwallet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gcash", "Paymaya", "Paypal" }));
        lEwallet.setEnabled(false);
        jPanel2.add(lEwallet, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, 150, -1));

        jLabel18.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel18.setText("Enter Cash Amount:");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 180, -1));

        txAmount.setFont(new java.awt.Font("Trebuchet MS", 0, 16)); // NOI18N
        txAmount.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txAmount.setEnabled(false);
        jPanel2.add(txAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 300, 38));

        btnPayNow.setFont(new java.awt.Font("Franklin Gothic Book", 1, 20)); // NOI18N
        btnPayNow.setText("Pay Now");
        btnPayNow.setEnabled(false);
        btnPayNow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPayNowActionPerformed(evt);
            }
        });
        jPanel2.add(btnPayNow, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 450, 160, 30));

        txCn.setFont(new java.awt.Font("Trebuchet MS", 0, 16)); // NOI18N
        txCn.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txCn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txCn.setEnabled(false);
        jPanel2.add(txCn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 300, 40));

        txName.setFont(new java.awt.Font("Trebuchet MS", 0, 16)); // NOI18N
        txName.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txName.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        txName.setEnabled(false);
        jPanel2.add(txName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 300, 40));

        jLabel6.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel6.setText("Contact Number: ");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jLabel12.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel12.setText("Full Name: ");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, 40));

        btnPriceList.setFont(new java.awt.Font("Franklin Gothic Book", 1, 16)); // NOI18N
        btnPriceList.setText("Check Services Price List");
        btnPriceList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPriceListActionPerformed(evt);
            }
        });
        jPanel2.add(btnPriceList, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 320, 30));

        jLabel32.setBackground(new java.awt.Color(132, 150, 134));
        jLabel32.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel32.setOpaque(true);
        jPanel2.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 530, 340, 40));

        jLabel34.setBackground(new java.awt.Color(132, 150, 134));
        jLabel34.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(51, 51, 51), new java.awt.Color(204, 204, 204), new java.awt.Color(51, 51, 51), new java.awt.Color(255, 255, 255)));
        jLabel34.setOpaque(true);
        jPanel2.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, 50));

        Services.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 40, 350, 570));

        btnSubmit.setFont(new java.awt.Font("Franklin Gothic Book", 1, 14)); // NOI18N
        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
        Services.add(btnSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 578, 80, 25));

        btnReset.setFont(new java.awt.Font("Franklin Gothic Book", 1, 14)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });
        Services.add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 578, 80, 25));

        jLabel4.setBackground(new java.awt.Color(232, 227, 215));
        jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel4.setOpaque(true);
        Services.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 570, 670, 40));

        jLabel8.setText(".........................................................................................................................................................................................................................");
        Services.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 470, 530, 30));

        jLabel24.setText(".........................................................................................................................................................................................................................");
        Services.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 530, 30));

        jLabel26.setText(".........................................................................................................................................................................................................................");
        Services.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 530, 30));

        jLabel29.setText(".........................................................................................................................................................................................................................");
        Services.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 530, 30));

        jLabel30.setText("............................................................................................................................................................................................................................................");
        Services.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 360, 540, 30));

        jPanel1.add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 980, 610));

        jPanel6.setBackground(new java.awt.Color(232, 227, 215));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lmop.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        lmop.setText("Payment Method:");
        jPanel6.add(lmop, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 360, 30));

        dName.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        dName.setText("Name: ");
        jPanel6.add(dName, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 310, 30));

        dCn.setFont(new java.awt.Font("Trebuchet MS", 1, 16)); // NOI18N
        dCn.setText("Contact Number: ");
        jPanel6.add(dCn, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 310, 30));

        Change.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        Change.setText("0.0");
        Change.setEnabled(false);
        jPanel6.add(Change, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 140, -1));

        l2.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15)); // NOI18N
        l2.setText("Cash.................................₱");
        l2.setEnabled(false);
        jPanel6.add(l2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, -1, 30));

        l1.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15)); // NOI18N
        l1.setText("Total Amount..........................₱");
        l1.setEnabled(false);
        jPanel6.add(l1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 99, -1, 30));

        l3.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15)); // NOI18N
        l3.setText("Change...........................₱");
        l3.setEnabled(false);
        jPanel6.add(l3, new org.netbeans.lib.awtextra.AbsoluteConstraints(72, 160, 180, -1));

        Cash.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        Cash.setText("0.0");
        Cash.setEnabled(false);
        jPanel6.add(Cash, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, 150, 30));

        TotalAmount.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        TotalAmount.setText("0.0");
        TotalAmount.setEnabled(false);
        jPanel6.add(TotalAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, 150, 30));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 750, 410, 200));

        jToggleButton2.setText("Enqueue");
        jPanel1.add(jToggleButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 960, -1, 30));

        jPanel5.setBackground(new java.awt.Color(232, 227, 215));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lSched2.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        lSched2.setText("Hair Cut................");
        jPanel5.add(lSched2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        haircut.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        haircut.setText("None");
        jPanel5.add(haircut, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 200, -1));

        haircolor.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        haircolor.setText("None");
        jPanel5.add(haircolor, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 200, -1));

        lSched3.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        lSched3.setText("Hair Color.............");
        jPanel5.add(lSched3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        lSched4.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        lSched4.setText("Hair Style..............");
        jPanel5.add(lSched4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        hairstyle.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        hairstyle.setText("None");
        jPanel5.add(hairstyle, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 190, -1));

        waxing.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        waxing.setText("None");
        jPanel5.add(waxing, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 200, -1));

        lSched5.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        lSched5.setText("Waxing.................");
        jPanel5.add(lSched5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        label2.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        label2.setText("Nail Treatments.....");
        jPanel5.add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        nailtreatment.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        nailtreatment.setText("None");
        jPanel5.add(nailtreatment, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 210, 40));

        label3.setFont(new java.awt.Font("Trebuchet MS", 1, 17)); // NOI18N
        label3.setText("VAT Amount");
        jPanel5.add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, -1, 40));

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        jLabel2.setText("Total Price");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, -1, 30));

        jLabel20.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel20.setText("₱");
        jPanel5.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 20, 30));

        jLabel17.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel17.setText("₱");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 150, 20, 30));

        jLabel22.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel22.setText("₱");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 20, 30));

        jLabel16.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel16.setText("₱");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 20, 30));

        jLabel15.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel15.setText("₱");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 60, 20, 30));

        jLabel14.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel14.setText("₱");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 30, 20, 30));

        jLabel13.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel13.setText("₱");
        jPanel5.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 20, 30));

        haircutPrice.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        haircutPrice.setText("0.0");
        jPanel5.add(haircutPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 90, 30));

        haircolorPrice.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        haircolorPrice.setText("0.0");
        jPanel5.add(haircolorPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 30, 120, 30));

        hairstylePrice.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        hairstylePrice.setText("0.0");
        jPanel5.add(hairstylePrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 60, 120, 30));

        waxingPrice.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        waxingPrice.setText("0.0");
        jPanel5.add(waxingPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 90, 120, 30));

        nailtreatmentPrice.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        nailtreatmentPrice.setText("0.0");
        jPanel5.add(nailtreatmentPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 120, 30));

        vatP.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        vatP.setText("0.0");
        jPanel5.add(vatP, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 110, 30));

        totalprice.setFont(new java.awt.Font("Bahnschrift", 1, 19)); // NOI18N
        totalprice.setText("0.0");
        jPanel5.add(totalprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, 120, 30));

        jLabel1.setBackground(new java.awt.Color(236, 234, 230));
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel1.setOpaque(true);
        jPanel5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 180, 610, 30));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 740, 570, 230));

        jLabel5.setBackground(new java.awt.Color(132, 150, 134));
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel5.setOpaque(true);
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 1000, 990, 20));

        btnEnqueue.setFont(new java.awt.Font("Franklin Gothic Book", 1, 16)); // NOI18N
        btnEnqueue.setText("Enqueue");
        btnEnqueue.setEnabled(false);
        btnEnqueue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnqueueActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnqueue, new org.netbeans.lib.awtextra.AbsoluteConstraints(853, 960, 120, 30));

        jLabel33.setBackground(new java.awt.Color(132, 150, 134));
        jLabel33.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel33.setOpaque(true);
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1000, 50));

        jLabel31.setBackground(new java.awt.Color(210, 176, 176));
        jLabel31.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel31.setOpaque(true);
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 52, 1020, 10));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 1020));

        jPanel4.setBackground(new java.awt.Color(132, 150, 134));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        queueList.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jPanel4.add(queueList, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 340, 840));

        jLabel106.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel106.setText("Customer's List");
        jPanel4.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, -1, 50));

        btnDequeue.setFont(new java.awt.Font("Franklin Gothic Book", 1, 16)); // NOI18N
        btnDequeue.setText("Dequeue");
        btnDequeue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDequeueActionPerformed(evt);
            }
        });
        jPanel4.add(btnDequeue, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 960, 280, 30));

        btnLogOut.setFont(new java.awt.Font("Franklin Gothic Book", 1, 16)); // NOI18N
        btnLogOut.setText("Log Out");
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });
        jPanel4.add(btnLogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 370, -1));

        jLabel35.setBackground(new java.awt.Color(132, 150, 134));
        jLabel35.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel35.setOpaque(true);
        jPanel4.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 940, 340, 60));

        jLabel36.setBackground(new java.awt.Color(132, 150, 134));
        jLabel36.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel36.setOpaque(true);
        jPanel4.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 430, 50));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 0, 440, 1020));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    public void HairCut()
    {
        if (a1.isSelected())
        {
            HairCut = a1.getText();
            haircutP = 250.0;  
        }
        if (a2.isSelected())
        {
            HairCut = a2.getText();
            haircutP = 350.0;
        }          
        if (a3.isSelected())
        {
            HairCut = a3.getText();
            haircutP = 150.0;
        }
        if (a4.isSelected())
        {
            HairCut = a4.getText();
            haircutP = 200.0;
        }
        if (a5.isSelected())
        {
            HairCut = a5.getText();
            haircutP = 300.0;
        }
        if (a6.isSelected())
        {
            HairCut = a6.getText();
            haircutP = 200.0;
        }      
        haircut.setText(HairCut);
        haircutPrice.setText(String.valueOf(haircutP));
    }
    
    public void HairColor()
    {
        if (b1.isSelected())
        {
            HairColor = b1.getText();
            haircolorP = 1000.0;   
        }
        if (b2.isSelected())
        {
            HairColor = b2.getText();
            haircolorP = 2000.0;
        }          
        if (b3.isSelected())
        {
            HairColor = b3.getText();
            haircolorP = 1500.0;
        }
        if (b4.isSelected())
        {
            HairColor = b4.getText();
            haircolorP = 500.0;
        }
        if (b5.isSelected())
        {
            HairColor = b5.getText();
            haircolorP = 2000.0;
        }
        if (b6.isSelected())
        {
            HairColor = b6.getText();
            haircolorP = 2000.0;
        }        
        haircolor.setText(HairColor);
        haircolorPrice.setText(String.valueOf(haircolorP));
    }
    
    public void HairStyle()
    {
        if (c1.isSelected())
        {
            HairStyle = c1.getText();
            hairstyleP = 700.0;       
        }
        if (c2.isSelected())
        {
            HairStyle = c2.getText();
            hairstyleP = 500.0; 
        }          
        if (c3.isSelected())
        {
            HairStyle = c3.getText();
            hairstyleP = 500.0; 
        }
        if (c4.isSelected())
        {
            HairStyle = c4.getText();
            hairstyleP = 650.0; 
        }
        if (c5.isSelected())
        {
            HairStyle = c5.getText();
            hairstyleP = 600.0; 
        }
        if (c6.isSelected())
        {
            HairStyle = c6.getText();
            hairstyleP = 1000.0; 
        }           
        hairstyle.setText(HairStyle);
        hairstylePrice.setText(String.valueOf(hairstyleP));
    }
    
    public void Waxing()
    {
        if (d1.isSelected())
        {
            Waxing = d1.getText();
            waxingP = 300.0;       
        }
        if (d2.isSelected())
        {
            Waxing = d2.getText();
            waxingP = 500.0;
        }          
        if (d3.isSelected())
        {
            Waxing = d3.getText();
            waxingP = 1000.0;
        }
        if (d4.isSelected())
        {
            Waxing = d4.getText();
            waxingP = 700.0;
        }
        if (d5.isSelected())
        {
            Waxing = d5.getText();
            waxingP = 250.0;
        }
        if (d6.isSelected())
        {
            Waxing = d6.getText();
            waxingP = 1000.0;
        }  
        waxing.setText(Waxing);
        waxingPrice.setText(String.valueOf(waxingP));
    }
    
    public void NailTreatment()
    {
        if (e1.isSelected())
        {
            NailTreatment = e1.getText();
            nailtreatmentP = 500.0;       
        }
        if (e2.isSelected())
        {
            NailTreatment = e2.getText();
            nailtreatmentP = 1000.0;
        }          
        if (e3.isSelected())
        {
            NailTreatment = e3.getText();
            nailtreatmentP = 1000.0;
        }
        if (e4.isSelected())
        {
            NailTreatment = e4.getText();
            nailtreatmentP = 800.0;
        }
        if (e5.isSelected())
        {
            NailTreatment = e5.getText();
            nailtreatmentP = 1500.0;
        }
        if (e6.isSelected())
        {
            NailTreatment = e6.getText();
            nailtreatmentP = 1150.0;
        }                  
        nailtreatment.setText(NailTreatment);
        nailtreatmentPrice.setText(String.valueOf(nailtreatmentP));
    }
    
    public void Reset()
    {
        buttonGroup1.clearSelection();
        buttonGroup2.clearSelection();
        buttonGroup3.clearSelection();
        buttonGroup4.clearSelection();
        buttonGroup5.clearSelection();
        mop.clearSelection();
        
        haircut.setText("None");
        haircolor.setText("None");
        hairstyle.setText("None");
        waxing.setText("None");
        nailtreatment.setText("None");
        
        haircutPrice.setText("0.0");
        haircolorPrice.setText("0.0");
        hairstylePrice.setText("0.0");
        waxingPrice.setText("0.0");
        nailtreatmentPrice.setText("0.0");
        vatP.setText("0.0");
        totalprice.setText("0.0");
        
        txName.setText("");      
        txCn.setText("");
        txAmount.setText("");
        
        dName.setText("Name: ");
        dCn.setText("Contact Number: ");
        lmop.setText("Payment Method: ");
        
        TotalAmount.setText("0.0");
        Cash.setText("0.0");
        Change.setText("0.0");
        
        HairCut = "None";
        HairColor = "None";
        HairStyle = "None";
        Waxing = "None";
        NailTreatment = "None";
        
        haircutP = 0.0;
        haircolorP = 0.0;
        hairstyleP = 0.0;
        waxingP = 0.0;
        nailtreatmentP = 0.0;
        total = 0.0;
        vat = 0.0;

        btnPayNow.setEnabled(false);
        btnEnqueue.setEnabled(false);
        
        txName.setEnabled(false);
        txCn.setEnabled(false);
        cbCash.setEnabled(false);
        cbEwallet.setEnabled(false);     
        lEwallet.setEnabled(false);
        
        l1.setEnabled(false); TotalAmount.setEnabled(false);
        l2.setEnabled(false); Cash.setEnabled(false);
        l3.setEnabled(false); Change.setEnabled(false);
    }
    
    public void Details()
    {
        dName.setText("Name: " + txName.getText());
        dCn.setText("Contact Number: " + txCn.getText());
    }
    
    public void enqueue() 
    {
        customerName = txName.getText();
        contactNumber = txCn.getText();
        
        s1 = HairCut;
        s2 = HairColor;
        s3 = HairStyle;
        s4 = Waxing;
        s5 = NailTreatment;
        
        if ((rear+1)%size==front) 
        {
            warning.showMessageDialog(this,"Queue is Full.","Alert",JOptionPane.WARNING_MESSAGE);
        } 
        else 
        {
            if (front== -1) 
            {
                front= 0;
            }
            customerQueNum = value++;
            
            rear= (rear+1)%size; 
            customers[rear]= customerName;
            customersCn[rear]= contactNumber;
            queNumber[rear] = customerQueNum;
            
            haircutChoice[rear] = s1;
            haircolorChoice [rear] = s2;
            hairstyleChoice [rear] = s3;
            waxingChoice [rear] = s4;
            nailtreatmentChoice [rear] = s5;
            
            queueList.add("-----------Queue #" + customerQueNum + "-----------");
            queueList.add("Name: " + customerName);
            queueList.add("Contact Number: " + String.valueOf(contactNumber));
            queueList.add("");
            queueList.add("Hair Cut: " + s1);
            queueList.add("Hair Color: " + s2);
            queueList.add("Hair Style: " + s3);
            queueList.add("Waxing: " + s4);
            queueList.add("Nail Treatment: " + s5);
            queueList.add("");
            
        }
    }

    public void dequeue() 
    {
        if (front==-1) 
        {
            warning.showMessageDialog(this,"Queue is Empty.","Alert",JOptionPane.WARNING_MESSAGE);
        } 
        else 
        {
            customerName= customers[front];
            contactNumber = customersCn[front];
            customerQueNum = queNumber[front];
            
            s1 = haircutChoice[front]; 
            s2 = haircolorChoice[front]; 
            s3 = hairstyleChoice[front]; 
            s4 = waxingChoice[front]; 
            s5 = nailtreatmentChoice[front]; 
            
            queueList.remove("-----------Queue #" + customerQueNum + "-----------");
            queueList.remove("Name: " + customerName);
            queueList.remove("Contact Number: " + String.valueOf(contactNumber));
            queueList.remove("");
            queueList.remove("Hair Cut: " + s1);
            queueList.remove("Hair Color: " + s2);
            queueList.remove("Hair Style: " + s3);
            queueList.remove("Waxing: " + s4);
            queueList.remove("Nail Treatment: " + s5);
            queueList.remove("");

            if (front==rear) 
            {
                front= -1;
                rear= -1;
            } 
            else 
            {
                front= (front + 1)%size; 
            }
        }
    }
    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
                    
            Details();
            HairCut();
            HairColor();
            HairStyle();
            Waxing();
            NailTreatment();      
 
            total = haircutP+haircolorP+hairstyleP+waxingP+nailtreatmentP;
            vat = total*.12;
            total = total+vat;            
            vatP.setText(String.valueOf(vat));
            totalprice.setText(String.valueOf(total));     
            
            btnPayNow.setEnabled(true);
            txName.setEnabled(true);
            txCn.setEnabled(true);
            cbCash.setEnabled(true);
            cbEwallet.setEnabled(true);
            
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnPayNowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPayNowActionPerformed
        
        if (txName.getText().isEmpty() || txCn.getText().isEmpty() || mop.getButtonCount() == 0)
        {
            warning.showMessageDialog(this,"Please fill all the Requirements!","Alert",JOptionPane.WARNING_MESSAGE);
        }
        else if (cbCash.isSelected())
        {
            double totalP = Double.parseDouble(totalprice.getText());
            double givenCash = Double.parseDouble(txAmount.getText());
            double customersChange = givenCash - totalP;     
            
            if (cbCash.isSelected() && givenCash<totalP)
            {
                warning.showMessageDialog(this,"Insufficient Balance","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else if (cbCash.isSelected() && givenCash>=totalP)
            {
                lmop.setText("Payment Method: Cash");
                TotalAmount.setText(String.valueOf(totalP));
                Cash.setText(String.valueOf(givenCash));
                Change.setText(String.valueOf(customersChange));
                Details();
                
                l1.setEnabled(true); TotalAmount.setEnabled(true);
                l2.setEnabled(true); Cash.setEnabled(true);
                l3.setEnabled(true); Change.setEnabled(true);
                
                btnEnqueue.setEnabled(true);
            }
        }
        else if (cbEwallet.isSelected())
        {
            Details();
            lmop.setText("Payment Method: Ewallet (" + lEwallet.getSelectedItem() + ")");
            btnEnqueue.setEnabled(true);
        }    
        
    }//GEN-LAST:event_btnPayNowActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
     
        Reset();
        
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnEnqueueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnqueueActionPerformed
        
        enqueue();
        Reset();
        
    }//GEN-LAST:event_btnEnqueueActionPerformed

    private void btnPriceListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPriceListActionPerformed

        new Services().setVisible(true);
        
    }//GEN-LAST:event_btnPriceListActionPerformed

    private void btnDequeueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDequeueActionPerformed
        
        dequeue();
        
    }//GEN-LAST:event_btnDequeueActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
    
    if (warning.showConfirmDialog(this,"Log Out?","Alert",warning.OK_CANCEL_OPTION)==warning.OK_OPTION)
               {
                new A_LogIn().setVisible(true);
                dispose();
               }
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void cbCashStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_cbCashStateChanged

        if (cbCash.isSelected() == true)
        {
            txAmount.setEnabled(true);
            lEwallet.setEnabled(false);
        }
        else
        {
            txAmount.setEnabled(false);
            lEwallet.setEnabled(true);
        }
    }//GEN-LAST:event_cbCashStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(B_AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(B_AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(B_AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(B_AdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new B_AdminPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Cash;
    private javax.swing.JLabel Change;
    private javax.swing.JPanel Services;
    private javax.swing.JLabel TotalAmount;
    public javax.swing.JCheckBox a1;
    public javax.swing.JCheckBox a2;
    public javax.swing.JCheckBox a3;
    public javax.swing.JCheckBox a4;
    public javax.swing.JCheckBox a5;
    public javax.swing.JCheckBox a6;
    public javax.swing.JCheckBox b1;
    public javax.swing.JCheckBox b2;
    public javax.swing.JCheckBox b3;
    public javax.swing.JCheckBox b4;
    public javax.swing.JCheckBox b5;
    public javax.swing.JCheckBox b6;
    private javax.swing.JButton btnDequeue;
    private javax.swing.JButton btnEnqueue;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnPayNow;
    private javax.swing.JToggleButton btnPriceList;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSubmit;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    public javax.swing.JCheckBox c1;
    public javax.swing.JCheckBox c2;
    public javax.swing.JCheckBox c3;
    public javax.swing.JCheckBox c4;
    public javax.swing.JCheckBox c5;
    public javax.swing.JCheckBox c6;
    private javax.swing.JCheckBox cbCash;
    private javax.swing.JCheckBox cbEwallet;
    public javax.swing.JCheckBox d1;
    public javax.swing.JCheckBox d2;
    public javax.swing.JCheckBox d3;
    public javax.swing.JCheckBox d4;
    public javax.swing.JCheckBox d5;
    public javax.swing.JCheckBox d6;
    public javax.swing.JLabel dCn;
    public javax.swing.JLabel dName;
    public javax.swing.JCheckBox e1;
    public javax.swing.JCheckBox e2;
    public javax.swing.JCheckBox e3;
    public javax.swing.JCheckBox e4;
    public javax.swing.JCheckBox e5;
    public javax.swing.JCheckBox e6;
    public javax.swing.JLabel haircolor;
    public javax.swing.JLabel haircolorPrice;
    public javax.swing.JLabel haircut;
    public javax.swing.JLabel haircutPrice;
    public javax.swing.JLabel hairstyle;
    public javax.swing.JLabel hairstylePrice;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JLabel l1;
    private javax.swing.JLabel l2;
    private javax.swing.JLabel l3;
    private javax.swing.JComboBox<String> lEwallet;
    private javax.swing.JLabel lSched2;
    private javax.swing.JLabel lSched3;
    private javax.swing.JLabel lSched4;
    private javax.swing.JLabel lSched5;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    private javax.swing.JLabel lmop;
    private javax.swing.ButtonGroup mop;
    public javax.swing.JLabel nailtreatment;
    public javax.swing.JLabel nailtreatmentPrice;
    private javax.swing.JFrame pricelist;
    private java.awt.List queueList;
    public javax.swing.JLabel totalprice;
    private javax.swing.JTextField txAmount;
    private javax.swing.JTextField txCn;
    private javax.swing.JTextField txName;
    public javax.swing.JLabel vatP;
    private javax.swing.JOptionPane warning;
    public javax.swing.JLabel waxing;
    public javax.swing.JLabel waxingPrice;
    // End of variables declaration//GEN-END:variables
}
