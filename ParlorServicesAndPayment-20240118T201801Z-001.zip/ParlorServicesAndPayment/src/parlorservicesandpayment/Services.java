package parlorservicesandpayment;

public class Services extends javax.swing.JFrame {
 
    public Services() {
        initComponents();

    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        frameHairColor = new javax.swing.JFrame();
        panelHaircolor = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        btnNextHairColor = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        prevHaircolor = new javax.swing.JButton();
        frameHairStyle = new javax.swing.JFrame();
        panelHairStyle = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btnHairStyle = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jLabel124 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        prevHairStyle = new javax.swing.JButton();
        frameWaxing = new javax.swing.JFrame();
        panelWaxing = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jLabel128 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        jLabel130 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        btnWaxing = new javax.swing.JButton();
        prevWaxing = new javax.swing.JButton();
        frameNailTreatment = new javax.swing.JFrame();
        panelNailtreatment = new javax.swing.JPanel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel105 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        jLabel132 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        jLabel134 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        btnNailTreatment = new javax.swing.JButton();
        prevNailTreatment = new javax.swing.JButton();
        panelHaircut = new javax.swing.JPanel();
        Lservices = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        btnNext = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        pHaircut = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        frameHairColor.setTitle("Price List");
        frameHairColor.setBounds(new java.awt.Rectangle(300, 100, 1325, 900));
        frameHairColor.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        panelHaircolor.setBackground(new java.awt.Color(232, 227, 215));
        panelHaircolor.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel43.setBackground(new java.awt.Color(127, 170, 127));
        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel43.setText(" ₱ 2000");
        jLabel43.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel43.setOpaque(true);
        panelHaircolor.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 500, 90, 30));

        jLabel44.setBackground(new java.awt.Color(127, 170, 127));
        jLabel44.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel44.setText(" ₱ 2000");
        jLabel44.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel44.setOpaque(true);
        panelHaircolor.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 500, 90, 30));

        jLabel45.setBackground(new java.awt.Color(127, 170, 127));
        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel45.setText(" ₱ 1500");
        jLabel45.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel45.setOpaque(true);
        panelHaircolor.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 270, 90, 30));

        jLabel46.setBackground(new java.awt.Color(127, 170, 127));
        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel46.setText(" ₱ 1000");
        jLabel46.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel46.setOpaque(true);
        panelHaircolor.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, 90, 30));

        jLabel47.setBackground(new java.awt.Color(127, 170, 127));
        jLabel47.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel47.setText(" ₱ 2000");
        jLabel47.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel47.setOpaque(true);
        panelHaircolor.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 270, -1, 30));

        jLabel48.setBackground(new java.awt.Color(127, 170, 127));
        jLabel48.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel48.setText(" ₱ 1000");
        jLabel48.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel48.setOpaque(true);
        panelHaircolor.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 90, 30));

        btnNextHairColor.setBackground(new java.awt.Color(228, 219, 219));
        btnNextHairColor.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        btnNextHairColor.setText("Next");
        btnNextHairColor.setBorder(null);
        btnNextHairColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextHairColorActionPerformed(evt);
            }
        });
        panelHaircolor.add(btnNextHairColor, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 20, 110, 30));

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Auburn.png"))); // NOI18N
        jLabel50.setText("jLabel3");
        jLabel50.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHaircolor.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 510, 250, 130));

        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/highlights.png"))); // NOI18N
        jLabel51.setText("jLabel3");
        jLabel51.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHaircolor.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 250, 130));

        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Ashgray.png"))); // NOI18N
        jLabel53.setText("jLabel3");
        jLabel53.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHaircolor.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, 250, 130));

        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/under.png"))); // NOI18N
        jLabel54.setText("jLabel3");
        jLabel54.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHaircolor.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 280, 250, 130));

        jLabel55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Ombre.png"))); // NOI18N
        jLabel55.setText("jLabel3");
        jLabel55.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHaircolor.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, 250, 130));

        jLabel56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/caramel.png"))); // NOI18N
        jLabel56.setText("jLabel3");
        jLabel56.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHaircolor.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 510, 250, 130));

        jLabel57.setBackground(new java.awt.Color(210, 176, 176));
        jLabel57.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText("HairCut >> Hair Color >> HairStyle >> Waxing >> Nail Treatments");
        jLabel57.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel57.setOpaque(true);
        panelHaircolor.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 810, 40));

        jPanel12.setBackground(new java.awt.Color(210, 176, 176));
        jPanel12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1356, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        panelHaircolor.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 730, 1360, 20));

        jPanel13.setBackground(new java.awt.Color(132, 150, 134));
        jPanel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1316, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        panelHaircolor.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 810, 1320, 40));

        jPanel15.setBackground(new java.awt.Color(238, 235, 226));
        jPanel15.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel63.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel63.setText("Hair Color");
        jPanel15.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 180, 100));

        jLabel113.setBackground(new java.awt.Color(210, 176, 176));
        jLabel113.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel113.setText("Ombre");
        jLabel113.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel113.setOpaque(true);
        jPanel15.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, 250, 40));

        jLabel114.setBackground(new java.awt.Color(210, 176, 176));
        jLabel114.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel114.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel114.setText("Highlights");
        jLabel114.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel114.setOpaque(true);
        jPanel15.add(jLabel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 250, 40));

        jLabel115.setBackground(new java.awt.Color(210, 176, 176));
        jLabel115.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel115.setText("Ashgray Hair Color");
        jLabel115.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel115.setOpaque(true);
        jPanel15.add(jLabel115, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 250, 40));

        jLabel116.setBackground(new java.awt.Color(210, 176, 176));
        jLabel116.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel116.setText("Under-Hair Color");
        jLabel116.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel116.setOpaque(true);
        jPanel15.add(jLabel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 250, 250, 40));

        jLabel117.setBackground(new java.awt.Color(210, 176, 176));
        jLabel117.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel117.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel117.setText("Auburn Hair Color");
        jLabel117.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel117.setOpaque(true);
        jPanel15.add(jLabel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 480, 250, 40));

        jLabel118.setBackground(new java.awt.Color(210, 176, 176));
        jLabel118.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel118.setText("Caramel Highlights");
        jLabel118.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel118.setOpaque(true);
        jPanel15.add(jLabel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 480, 250, 40));

        panelHaircolor.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 1120, 580));

        jPanel8.setBackground(new java.awt.Color(132, 150, 134));
        jPanel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel31.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel31.setText("Price List");
        jPanel8.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 150, 60));

        prevHaircolor.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        prevHaircolor.setText("Prev");
        prevHaircolor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevHaircolorActionPerformed(evt);
            }
        });
        jPanel8.add(prevHaircolor, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 110, 30));

        panelHaircolor.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 70));

        javax.swing.GroupLayout frameHairColorLayout = new javax.swing.GroupLayout(frameHairColor.getContentPane());
        frameHairColor.getContentPane().setLayout(frameHairColorLayout);
        frameHairColorLayout.setHorizontalGroup(
            frameHairColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1420, Short.MAX_VALUE)
            .addGroup(frameHairColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(frameHairColorLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelHaircolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        frameHairColorLayout.setVerticalGroup(
            frameHairColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 850, Short.MAX_VALUE)
            .addGroup(frameHairColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(frameHairColorLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelHaircolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        frameHairStyle.setTitle("Price List");
        frameHairStyle.setBounds(new java.awt.Rectangle(300, 100, 1325, 900));
        frameHairStyle.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelHairStyle.setBackground(new java.awt.Color(232, 227, 215));
        panelHairStyle.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setBackground(new java.awt.Color(127, 170, 127));
        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel17.setText(" ₱ 1000");
        jLabel17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel17.setOpaque(true);
        panelHairStyle.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 500, 90, 30));

        jLabel18.setBackground(new java.awt.Color(127, 170, 127));
        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel18.setText(" ₱ 600");
        jLabel18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel18.setOpaque(true);
        panelHairStyle.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 500, 70, 30));

        jLabel19.setBackground(new java.awt.Color(127, 170, 127));
        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel19.setText(" ₱ 500");
        jLabel19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel19.setOpaque(true);
        panelHairStyle.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 270, 70, 30));

        jLabel20.setBackground(new java.awt.Color(127, 170, 127));
        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel20.setText(" ₱ 650");
        jLabel20.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel20.setOpaque(true);
        panelHairStyle.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, 70, 30));

        jLabel21.setBackground(new java.awt.Color(127, 170, 127));
        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel21.setText(" ₱ 500");
        jLabel21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel21.setOpaque(true);
        panelHairStyle.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 270, 70, 30));

        jLabel22.setBackground(new java.awt.Color(127, 170, 127));
        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel22.setText(" ₱ 700");
        jLabel22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel22.setOpaque(true);
        panelHairStyle.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 70, 30));

        btnHairStyle.setBackground(new java.awt.Color(228, 219, 219));
        btnHairStyle.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        btnHairStyle.setText("Next");
        btnHairStyle.setBorder(null);
        btnHairStyle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHairStyleActionPerformed(evt);
            }
        });
        panelHairStyle.add(btnHairStyle, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 20, 110, 30));

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/coily.png"))); // NOI18N
        jLabel23.setText("jLabel3");
        jLabel23.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHairStyle.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 510, 250, 130));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/straight.png"))); // NOI18N
        jLabel24.setText("jLabel3");
        jLabel24.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHairStyle.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 250, 130));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/loose.png"))); // NOI18N
        jLabel25.setText("jLabel3");
        jLabel25.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHairStyle.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, 250, 130));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/endcurls.png"))); // NOI18N
        jLabel26.setText("jLabel3");
        jLabel26.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHairStyle.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 280, 250, 130));

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/vol.png"))); // NOI18N
        jLabel27.setText("jLabel3");
        jLabel27.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHairStyle.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, 250, 130));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/tousled.png"))); // NOI18N
        jLabel28.setText("jLabel3");
        jLabel28.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelHairStyle.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 510, 250, 130));

        jLabel2.setBackground(new java.awt.Color(210, 176, 176));
        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("HairCut >> Hair Color >> HairStyle >> Waxing >> Nail Treatments");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel2.setOpaque(true);
        panelHairStyle.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 810, 40));

        jPanel6.setBackground(new java.awt.Color(210, 176, 176));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1356, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        panelHairStyle.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 730, 1360, 20));

        jPanel7.setBackground(new java.awt.Color(132, 150, 134));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1316, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        panelHairStyle.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 810, 1320, 40));

        jPanel10.setBackground(new java.awt.Color(238, 235, 226));
        jPanel10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel30.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel30.setText("Hair Style");
        jPanel10.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 170, 100));

        jLabel119.setBackground(new java.awt.Color(210, 176, 176));
        jLabel119.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel119.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel119.setText("Voluminous Curls");
        jLabel119.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel119.setOpaque(true);
        jPanel10.add(jLabel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, 250, 40));

        jLabel120.setBackground(new java.awt.Color(210, 176, 176));
        jLabel120.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setText("Straight Hair");
        jLabel120.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel120.setOpaque(true);
        jPanel10.add(jLabel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 250, 40));

        jLabel121.setBackground(new java.awt.Color(210, 176, 176));
        jLabel121.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel121.setText("Loose Waves");
        jLabel121.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel121.setOpaque(true);
        jPanel10.add(jLabel121, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 250, 40));

        jLabel122.setBackground(new java.awt.Color(210, 176, 176));
        jLabel122.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel122.setText("End Curls");
        jLabel122.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel122.setOpaque(true);
        jPanel10.add(jLabel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 250, 250, 40));

        jLabel123.setBackground(new java.awt.Color(210, 176, 176));
        jLabel123.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel123.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel123.setText("Coily Curls");
        jLabel123.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel123.setOpaque(true);
        jPanel10.add(jLabel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 480, 250, 40));

        jLabel124.setBackground(new java.awt.Color(210, 176, 176));
        jLabel124.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setText("Tousled Waves Hair");
        jLabel124.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel124.setOpaque(true);
        jPanel10.add(jLabel124, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 480, 250, 40));

        panelHairStyle.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 1120, 580));

        jPanel11.setBackground(new java.awt.Color(132, 150, 134));
        jPanel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel33.setText("Price List");
        jPanel11.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 150, 60));

        prevHairStyle.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        prevHairStyle.setText("Prev");
        prevHairStyle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevHairStyleActionPerformed(evt);
            }
        });
        jPanel11.add(prevHairStyle, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 110, 30));

        panelHairStyle.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 70));

        frameHairStyle.getContentPane().add(panelHairStyle, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        frameWaxing.setTitle("Price List");
        frameWaxing.setBounds(new java.awt.Rectangle(300, 100, 1325, 900));

        panelWaxing.setBackground(new java.awt.Color(232, 227, 215));
        panelWaxing.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel64.setBackground(new java.awt.Color(127, 170, 127));
        jLabel64.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel64.setText(" ₱ 1000");
        jLabel64.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel64.setOpaque(true);
        panelWaxing.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 500, 90, 30));

        jLabel65.setBackground(new java.awt.Color(127, 170, 127));
        jLabel65.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel65.setText(" ₱ 250");
        jLabel65.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel65.setOpaque(true);
        panelWaxing.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 500, 70, 30));

        jLabel66.setBackground(new java.awt.Color(127, 170, 127));
        jLabel66.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel66.setText(" ₱ 1000");
        jLabel66.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel66.setOpaque(true);
        panelWaxing.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 270, 90, 30));

        jLabel67.setBackground(new java.awt.Color(127, 170, 127));
        jLabel67.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel67.setText(" ₱ 700");
        jLabel67.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel67.setOpaque(true);
        panelWaxing.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, 70, 30));

        jLabel68.setBackground(new java.awt.Color(127, 170, 127));
        jLabel68.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel68.setText(" ₱ 500");
        jLabel68.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel68.setOpaque(true);
        panelWaxing.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 270, 70, 30));

        jLabel69.setBackground(new java.awt.Color(127, 170, 127));
        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel69.setText(" ₱ 300");
        jLabel69.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel69.setOpaque(true);
        panelWaxing.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 70, 30));

        jLabel71.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/back.png"))); // NOI18N
        jLabel71.setText("jLabel3");
        jLabel71.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelWaxing.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 510, 250, 130));

        jLabel72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/underarm.png"))); // NOI18N
        jLabel72.setText("jLabel3");
        jLabel72.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelWaxing.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 250, 130));

        jLabel74.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/stomach.png"))); // NOI18N
        jLabel74.setText("jLabel3");
        jLabel74.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelWaxing.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, 250, 130));

        jLabel75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/leg.png"))); // NOI18N
        jLabel75.setText("jLabel3");
        jLabel75.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelWaxing.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 280, 250, 130));

        jLabel76.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/fullface.png"))); // NOI18N
        jLabel76.setText("jLabel3");
        jLabel76.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelWaxing.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, 250, 130));

        jLabel77.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eyebrow.png"))); // NOI18N
        jLabel77.setText("jLabel3");
        jLabel77.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelWaxing.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 510, 250, 130));

        jLabel78.setBackground(new java.awt.Color(210, 176, 176));
        jLabel78.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel78.setText("HairCut >> Hair Color >> HairStyle >> Waxing >> Nail Treatments");
        jLabel78.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel78.setOpaque(true);
        panelWaxing.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 810, 40));

        jPanel17.setBackground(new java.awt.Color(210, 176, 176));
        jPanel17.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1336, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        panelWaxing.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 730, 1340, 20));

        jPanel18.setBackground(new java.awt.Color(132, 150, 134));
        jPanel18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1306, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        panelWaxing.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 810, 1310, 40));

        jPanel20.setBackground(new java.awt.Color(238, 235, 226));
        jPanel20.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel84.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel84.setText("Waxing");
        jPanel20.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 130, 100));

        jLabel125.setBackground(new java.awt.Color(210, 176, 176));
        jLabel125.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel125.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel125.setText("Waxing Full Back");
        jLabel125.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel125.setOpaque(true);
        jPanel20.add(jLabel125, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 480, 250, 40));

        jLabel126.setBackground(new java.awt.Color(210, 176, 176));
        jLabel126.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel126.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel126.setText("Waxing Stomach");
        jLabel126.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel126.setOpaque(true);
        jPanel20.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 250, 40));

        jLabel127.setBackground(new java.awt.Color(210, 176, 176));
        jLabel127.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel127.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel127.setText("Waxing Underarm");
        jLabel127.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel127.setOpaque(true);
        jPanel20.add(jLabel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 250, 40));

        jLabel128.setBackground(new java.awt.Color(210, 176, 176));
        jLabel128.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel128.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel128.setText("Waxing Face");
        jLabel128.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel128.setOpaque(true);
        jPanel20.add(jLabel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, 250, 40));

        jLabel129.setBackground(new java.awt.Color(210, 176, 176));
        jLabel129.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel129.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel129.setText("Waxing Eyebrow");
        jLabel129.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel129.setOpaque(true);
        jPanel20.add(jLabel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 480, 250, 40));

        jLabel130.setBackground(new java.awt.Color(210, 176, 176));
        jLabel130.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel130.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel130.setText("Waxing Both Leg");
        jLabel130.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel130.setOpaque(true);
        jPanel20.add(jLabel130, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 250, 250, 40));

        panelWaxing.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 1120, 580));

        jPanel14.setBackground(new java.awt.Color(132, 150, 134));
        jPanel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel34.setText("Price List");
        jPanel14.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 150, 60));

        btnWaxing.setBackground(new java.awt.Color(228, 219, 219));
        btnWaxing.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        btnWaxing.setText("Next");
        btnWaxing.setBorder(null);
        btnWaxing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWaxingActionPerformed(evt);
            }
        });
        jPanel14.add(btnWaxing, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 20, 110, 30));

        prevWaxing.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        prevWaxing.setText("Prev");
        prevWaxing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevWaxingActionPerformed(evt);
            }
        });
        jPanel14.add(prevWaxing, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 110, 30));

        panelWaxing.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 70));

        javax.swing.GroupLayout frameWaxingLayout = new javax.swing.GroupLayout(frameWaxing.getContentPane());
        frameWaxing.getContentPane().setLayout(frameWaxingLayout);
        frameWaxingLayout.setHorizontalGroup(
            frameWaxingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1400, Short.MAX_VALUE)
            .addGroup(frameWaxingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(frameWaxingLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelWaxing, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        frameWaxingLayout.setVerticalGroup(
            frameWaxingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
            .addGroup(frameWaxingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(frameWaxingLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelWaxing, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        frameNailTreatment.setTitle("Price List");
        frameNailTreatment.setBounds(new java.awt.Rectangle(300, 100, 1325, 900));

        panelNailtreatment.setBackground(new java.awt.Color(232, 227, 215));
        panelNailtreatment.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel85.setBackground(new java.awt.Color(127, 170, 127));
        jLabel85.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel85.setText(" ₱ 1150");
        jLabel85.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel85.setOpaque(true);
        panelNailtreatment.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 500, 90, 30));

        jLabel86.setBackground(new java.awt.Color(127, 170, 127));
        jLabel86.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel86.setText(" ₱ 1500");
        jLabel86.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel86.setOpaque(true);
        panelNailtreatment.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 500, 90, 30));

        jLabel87.setBackground(new java.awt.Color(127, 170, 127));
        jLabel87.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel87.setText(" ₱ 1000");
        jLabel87.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel87.setOpaque(true);
        panelNailtreatment.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 270, 90, 30));

        jLabel88.setBackground(new java.awt.Color(127, 170, 127));
        jLabel88.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel88.setText(" ₱ 800");
        jLabel88.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel88.setOpaque(true);
        panelNailtreatment.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, 70, 30));

        jLabel89.setBackground(new java.awt.Color(127, 170, 127));
        jLabel89.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel89.setText(" ₱ 1000");
        jLabel89.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel89.setOpaque(true);
        panelNailtreatment.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 270, 90, 30));

        jLabel90.setBackground(new java.awt.Color(127, 170, 127));
        jLabel90.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel90.setText(" ₱ 500");
        jLabel90.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel90.setOpaque(true);
        panelNailtreatment.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 70, 30));

        jLabel92.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/hotOil.png"))); // NOI18N
        jLabel92.setText("jLabel3");
        jLabel92.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelNailtreatment.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 510, 250, 130));

        jLabel93.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/basic.png"))); // NOI18N
        jLabel93.setText("jLabel3");
        jLabel93.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelNailtreatment.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 250, 130));

        jLabel95.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/french.png"))); // NOI18N
        jLabel95.setText("jLabel3");
        jLabel95.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelNailtreatment.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 280, 250, 130));

        jLabel96.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/paraffin.png"))); // NOI18N
        jLabel96.setText("jLabel3");
        jLabel96.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelNailtreatment.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 280, 250, 130));

        jLabel97.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/gel.png"))); // NOI18N
        jLabel97.setText("jLabel3");
        jLabel97.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelNailtreatment.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, 250, 130));

        jLabel98.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/acrylic.png"))); // NOI18N
        jLabel98.setText("jLabel3");
        jLabel98.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelNailtreatment.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 510, 250, 130));

        jLabel99.setBackground(new java.awt.Color(210, 176, 176));
        jLabel99.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel99.setText("HairCut >> Hair Color >> HairStyle >> Waxing >> Nail Treatments");
        jLabel99.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel99.setOpaque(true);
        panelNailtreatment.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 810, 40));

        jPanel22.setBackground(new java.awt.Color(210, 176, 176));
        jPanel22.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1336, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        panelNailtreatment.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 730, 1340, 20));

        jPanel23.setBackground(new java.awt.Color(132, 150, 134));
        jPanel23.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1306, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        panelNailtreatment.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 810, 1310, 40));

        jPanel25.setBackground(new java.awt.Color(238, 235, 226));
        jPanel25.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel105.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel105.setText("Nail Treatment");
        jPanel25.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 240, 100));

        jLabel131.setBackground(new java.awt.Color(210, 176, 176));
        jLabel131.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel131.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel131.setText("Hot Oil Manicure");
        jLabel131.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel131.setOpaque(true);
        jPanel25.add(jLabel131, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 480, 250, 40));

        jLabel132.setBackground(new java.awt.Color(210, 176, 176));
        jLabel132.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel132.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel132.setText("Basic Manicure");
        jLabel132.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel132.setOpaque(true);
        jPanel25.add(jLabel132, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 250, 40));

        jLabel133.setBackground(new java.awt.Color(210, 176, 176));
        jLabel133.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel133.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel133.setText("French Manicure");
        jLabel133.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel133.setOpaque(true);
        jPanel25.add(jLabel133, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 250, 40));

        jLabel134.setBackground(new java.awt.Color(210, 176, 176));
        jLabel134.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        jLabel134.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel134.setText("Paraffin Wax Manicure");
        jLabel134.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel134.setOpaque(true);
        jPanel25.add(jLabel134, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 250, 250, 40));

        jLabel135.setBackground(new java.awt.Color(210, 176, 176));
        jLabel135.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel135.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel135.setText("Acrylic Nails");
        jLabel135.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel135.setOpaque(true);
        jPanel25.add(jLabel135, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 480, 250, 40));

        jLabel136.setBackground(new java.awt.Color(210, 176, 176));
        jLabel136.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel136.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel136.setText("Gel Manicure");
        jLabel136.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel136.setOpaque(true);
        jPanel25.add(jLabel136, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, 250, 40));

        panelNailtreatment.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 1120, 580));

        jPanel16.setBackground(new java.awt.Color(132, 150, 134));
        jPanel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel35.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel35.setText("Price List");
        jPanel16.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 150, 60));

        btnNailTreatment.setBackground(new java.awt.Color(228, 219, 219));
        btnNailTreatment.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        btnNailTreatment.setText("Next");
        btnNailTreatment.setBorder(null);
        btnNailTreatment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNailTreatmentActionPerformed(evt);
            }
        });
        jPanel16.add(btnNailTreatment, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 20, 110, 30));

        prevNailTreatment.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        prevNailTreatment.setText("Prev");
        prevNailTreatment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevNailTreatmentActionPerformed(evt);
            }
        });
        jPanel16.add(prevNailTreatment, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 110, 30));

        panelNailtreatment.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 70));

        javax.swing.GroupLayout frameNailTreatmentLayout = new javax.swing.GroupLayout(frameNailTreatment.getContentPane());
        frameNailTreatment.getContentPane().setLayout(frameNailTreatmentLayout);
        frameNailTreatmentLayout.setHorizontalGroup(
            frameNailTreatmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1400, Short.MAX_VALUE)
            .addGroup(frameNailTreatmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(frameNailTreatmentLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelNailtreatment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        frameNailTreatmentLayout.setVerticalGroup(
            frameNailTreatmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
            .addGroup(frameNailTreatmentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(frameNailTreatmentLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(panelNailtreatment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        setTitle("Price List");
        setBounds(new java.awt.Rectangle(300, 100, 500, 500));

        panelHaircut.setBackground(new java.awt.Color(232, 227, 215));
        panelHaircut.setPreferredSize(new java.awt.Dimension(1300, 850));
        panelHaircut.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Lservices.setBackground(new java.awt.Color(210, 176, 176));
        Lservices.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        Lservices.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Lservices.setText("HairCut >> Hair Color >> HairStyle >> Waxing >> Nail Treatments");
        Lservices.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        Lservices.setOpaque(true);
        panelHaircut.add(Lservices, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 810, 40));

        jPanel4.setBackground(new java.awt.Color(132, 150, 134));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1406, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        panelHaircut.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 810, 1410, 40));

        jPanel5.setBackground(new java.awt.Color(132, 150, 134));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnNext.setBackground(new java.awt.Color(228, 219, 219));
        btnNext.setFont(new java.awt.Font("Franklin Gothic Book", 1, 24)); // NOI18N
        btnNext.setText("Next");
        btnNext.setBorder(null);
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        jPanel5.add(btnNext, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 20, 110, 30));

        jLabel5.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel5.setText("Price List");
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 150, 60));

        panelHaircut.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1400, 70));

        jLabel36.setBackground(new java.awt.Color(210, 176, 176));
        jLabel36.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel36.setOpaque(true);
        panelHaircut.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 730, 1460, 20));

        pHaircut.setBackground(new java.awt.Color(238, 235, 226));
        pHaircut.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        pHaircut.setDoubleBuffered(false);
        pHaircut.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setBackground(new java.awt.Color(127, 170, 127));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel7.setText(" ₱ 250");
        jLabel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel7.setOpaque(true);
        pHaircut.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 110, -1, 30));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/PixieCut.png"))); // NOI18N
        jLabel6.setText("jLabel3");
        jLabel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pHaircut.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 250, 130));

        jLabel4.setBackground(new java.awt.Color(127, 170, 127));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel4.setText(" ₱ 350");
        jLabel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel4.setOpaque(true);
        pHaircut.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 110, -1, 30));

        jLabel32.setBackground(new java.awt.Color(210, 176, 176));
        jLabel32.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Straight Bob");
        jLabel32.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel32.setOpaque(true);
        pHaircut.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 470, 250, 40));

        jLabel13.setBackground(new java.awt.Color(127, 170, 127));
        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel13.setText(" ₱ 150");
        jLabel13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel13.setOpaque(true);
        pHaircut.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 110, -1, 30));

        jLabel12.setBackground(new java.awt.Color(127, 170, 127));
        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel12.setText(" ₱ 200");
        jLabel12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel12.setOpaque(true);
        pHaircut.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 340, -1, 30));

        jLabel15.setBackground(new java.awt.Color(127, 170, 127));
        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel15.setText(" ₱ 300");
        jLabel15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel15.setOpaque(true);
        pHaircut.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 340, -1, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Layered.png"))); // NOI18N
        jLabel11.setText("jLabel3");
        jLabel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pHaircut.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 350, 250, 130));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/AngledBob.png"))); // NOI18N
        jLabel3.setText("jLabel3");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pHaircut.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 350, 250, 130));

        jLabel14.setBackground(new java.awt.Color(127, 170, 127));
        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel14.setText(" ₱ 200");
        jLabel14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel14.setOpaque(true);
        pHaircut.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 340, -1, 30));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Bob.png"))); // NOI18N
        jLabel10.setText("jLabel3");
        jLabel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pHaircut.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 250, 130));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Undercut.png"))); // NOI18N
        jLabel8.setText("jLabel3");
        jLabel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pHaircut.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 120, 250, 130));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/HairTrim.png"))); // NOI18N
        jLabel9.setText("jLabel3");
        jLabel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pHaircut.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 120, 250, 130));

        jLabel108.setBackground(new java.awt.Color(210, 176, 176));
        jLabel108.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel108.setText("Pixie Cut");
        jLabel108.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel108.setOpaque(true);
        pHaircut.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 250, 40));

        jLabel109.setBackground(new java.awt.Color(210, 176, 176));
        jLabel109.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel109.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel109.setText("Undercut");
        jLabel109.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel109.setOpaque(true);
        pHaircut.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 250, 40));

        jLabel110.setBackground(new java.awt.Color(210, 176, 176));
        jLabel110.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("Hair Trimming");
        jLabel110.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel110.setOpaque(true);
        pHaircut.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 250, 250, 40));

        jLabel111.setBackground(new java.awt.Color(210, 176, 176));
        jLabel111.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel111.setText("Angled Bob");
        jLabel111.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel111.setOpaque(true);
        pHaircut.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 480, 250, 40));

        jLabel112.setBackground(new java.awt.Color(210, 176, 176));
        jLabel112.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel112.setText("Layered Hair");
        jLabel112.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel112.setOpaque(true);
        pHaircut.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 480, 250, 40));

        jLabel16.setFont(new java.awt.Font("Poor Richard", 1, 36)); // NOI18N
        jLabel16.setText("Hair Cut");
        pHaircut.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 140, 100));

        panelHaircut.add(pHaircut, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 1120, 580));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelHaircut, javax.swing.GroupLayout.PREFERRED_SIZE, 1309, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelHaircut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleName("frameHaircut");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed

        dispose();
        frameHairColor.setVisible(true);
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnNailTreatmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNailTreatmentActionPerformed

        frameNailTreatment.dispose();
        new Services().setVisible(true);
    }//GEN-LAST:event_btnNailTreatmentActionPerformed

    private void prevNailTreatmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevNailTreatmentActionPerformed
        frameNailTreatment.setVisible(false);
        frameWaxing.setVisible(true);
    }//GEN-LAST:event_prevNailTreatmentActionPerformed

    private void prevHaircolorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevHaircolorActionPerformed
        frameHairColor.setVisible(false);
        new Services().setVisible(true);
    }//GEN-LAST:event_prevHaircolorActionPerformed

    private void btnNextHairColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextHairColorActionPerformed

        frameHairColor.setVisible(false);
        frameHairStyle.setVisible(true);
    }//GEN-LAST:event_btnNextHairColorActionPerformed

    private void prevHairStyleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevHairStyleActionPerformed
        frameHairStyle.setVisible(false);
        frameHairColor.setVisible(true);
    }//GEN-LAST:event_prevHairStyleActionPerformed

    private void btnHairStyleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHairStyleActionPerformed

        frameHairStyle.setVisible(false);
        frameWaxing.setVisible(true);
    }//GEN-LAST:event_btnHairStyleActionPerformed

    private void prevWaxingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevWaxingActionPerformed
        frameWaxing.setVisible(false);
        frameHairStyle.setVisible(true);
    }//GEN-LAST:event_prevWaxingActionPerformed

    private void btnWaxingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWaxingActionPerformed

        frameWaxing.setVisible(false);
        frameNailTreatment.setVisible(true);
    }//GEN-LAST:event_btnWaxingActionPerformed


    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Services.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Services().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lservices;
    private javax.swing.JButton btnHairStyle;
    private javax.swing.JButton btnNailTreatment;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnNextHairColor;
    private javax.swing.JButton btnWaxing;
    private javax.swing.JFrame frameHairColor;
    private javax.swing.JFrame frameHairStyle;
    private javax.swing.JFrame frameNailTreatment;
    private javax.swing.JFrame frameWaxing;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel pHaircut;
    private javax.swing.JPanel panelHairStyle;
    private javax.swing.JPanel panelHaircolor;
    public javax.swing.JPanel panelHaircut;
    public javax.swing.JPanel panelNailtreatment;
    private javax.swing.JPanel panelWaxing;
    private javax.swing.JButton prevHairStyle;
    private javax.swing.JButton prevHaircolor;
    private javax.swing.JButton prevNailTreatment;
    private javax.swing.JButton prevWaxing;
    // End of variables declaration//GEN-END:variables
}
